#gerando cópias de segurança

#os backups que vão te proteger de problemas de querys erradas ou caso seu computador dê problema. Salve o backup na nuvem.

DESCRIBE acoes;

SHOW TABLES;

/*

Caminho cópia de segurança:

Server -> Data Export

A partir daí você irá selecionar os banco de dados, ou schemas para exportação e as tabelas a sua escolha.

Chamamos esse backup de dumps. Esses dumps podem ser estruturais, de dados ou os dois.

Vamos exportar um arquivo único responsável por guardar todas as informações. Não esqueça de marcar a opção de criar o database caso ele não exista!

Agora, pode exportar :)

Abrir Dump no VSCODE

Importar dump

Refaça isso que eu fiz ai na sua casa!

*/ 

DROP DATABASE codigopy;

USE codigopy;

SHOW TABLES;













