from galaxia_6_mundo_2 import Empresa


petro = Empresa(nome = "Petrobras", ticker = "PETR4")

print(petro.nome)


